@echo off
title Create Temp Maid Shortcut
color 0A
cls

echo.
echo   Want to create a desktop shortcut?
echo.
set /p choice="   (Y/N): "

if /i not "%choice%"=="Y" if /i not "%choice%"=="Yes" (
    echo.
    echo   Cancelled.
    timeout /t 2 >nul
    exit /b
)

echo.
echo   Creating shortcut...

:: Get the folder where this script is located
set "SCRIPT_DIR=%~dp0"

:: Path to TempMaid.bat (same folder)
set "TARGET=%SCRIPT_DIR%TempMaid.bat"

:: Path to the icon
set "ICON=%SCRIPT_DIR%icons\icon2.ico"

:: Desktop path
for /f "tokens=*" %%i in ('powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"') do set "DESKTOP=%%i"

:: Create the shortcut using a clean PowerShell command
powershell -NoProfile -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%DESKTOP%\Temp Maid.lnk'); $Shortcut.TargetPath = '%TARGET%'; $Shortcut.WorkingDirectory = '%SCRIPT_DIR%'; $Shortcut.IconLocation = '%ICON%'; $Shortcut.Description = 'Temp Maid - Clean temporary files'; $Shortcut.Save()"

if exist "%DESKTOP%\Temp Maid.lnk" (
    echo.
    echo   Shortcut created successfully on Desktop!
    echo   Name: Temp Maid
) else (
    echo.
    echo   Failed to create shortcut.
)

echo.
pause
