@echo off
title Temp Maid
color 0A
cls

echo Cleaning temporary files...
echo.

:: Permanently delete files in %TEMP% (no Recycle Bin)
del /f /q /s "%TEMP%\*.*" >nul 2>&1

:: Remove empty folders left behind
for /d %%D in ("%TEMP%\*") do rd /s /q "%%D" >nul 2>&1

:: Empty the Recycle Bin (permanent delete)
powershell -NoProfile -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue" >nul 2>&1

cls
echo.

:: Display the ASCII art (must be in the same folder)
type "%~dp0maid.txt"

echo.
echo   Thank You For Using Temp Maid
echo.
echo   Temporary files have been permanently deleted.
echo.
pause
